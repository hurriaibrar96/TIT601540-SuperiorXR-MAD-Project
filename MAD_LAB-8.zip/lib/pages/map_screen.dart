// pages/map_screen.dart
import 'package:flutter/material.dart';

class MapScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Icon(Icons.map, size: 100, color: Colors.grey),
    );
  }
}
