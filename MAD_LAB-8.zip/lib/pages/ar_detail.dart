// pages/ar_detail.dart
import 'package:flutter/material.dart';

class ARDetail extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double size = MediaQuery.of(context).size.shortestSide / 2;

    return Scaffold(
      appBar: AppBar(title: Text("AR View")),
      body: Center(
        child: Hero(
          tag: "ar_icon",
          child: Icon(Icons.view_in_ar, size: size, color: Colors.purple),
        ),
      ),
    );
  }
}
