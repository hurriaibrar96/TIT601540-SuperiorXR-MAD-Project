// pages/home.dart
import 'package:flutter/material.dart';
import 'about.dart';
import 'gratitude.dart';
import 'ar_screen.dart';
import 'map_screen.dart';
import 'profile.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String _userChoice = "...";
  int _currentIndex = 0;

  // Initialize _pages with a type annotation and a default value
  List<Widget> _pages = [];
  Widget _currentPage = Container(); // Initialize with a default widget

  @override
  void initState() {
    super.initState();

    _pages = [ARScreen(), MapScreen(), Profile()];
    _currentPage = _pages[0];
  }

  void _changePage(int index) {
    setState(() {
      _currentIndex = index;
      _currentPage = _pages[index];
    });
  }

  void _openAbout(
      {required BuildContext context, bool fullscreenDialog = true}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        fullscreenDialog: fullscreenDialog,
        builder: (context) => About(),
      ),
    );
  }

  void _openGratitude(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Gratitude(radioGroupValue: -1),
      ),
    );

    setState(() {
      _userChoice = result ?? "...";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Campus Guide"),
        actions: [
          IconButton(
            icon: Icon(Icons.info_outline),
            onPressed: () => _openAbout(context: context),
          )
        ],
      ),

      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              Text(
                "Selected: $_userChoice",
                style: TextStyle(fontSize: 22),
              ),
              Expanded(child: _currentPage),
            ],
          ),
        ),
      ),

      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.sentiment_satisfied),
        onPressed: () => _openGratitude(context),
      ),

      //  Bottom Navigation
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.purple,
        onTap: _changePage,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.view_in_ar),
            label: "AR View",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.map),
            label: "Map",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Profile",
          ),
        ],
      ),
    );
  }
}
