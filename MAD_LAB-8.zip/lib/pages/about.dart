// pages/about.dart
import 'package:flutter/material.dart';

class About extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("About"),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Text(
            "AI-Powered AR/VR Campus Guide\n\n"
            "Helps students navigate campus using AR & AI.",
            style: TextStyle(fontSize: 18),
          ),
        ),
      ),
    );
  }
}
