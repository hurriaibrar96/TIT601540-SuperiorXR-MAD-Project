// pages/gratitude.dart
import 'package:flutter/material.dart';

class Gratitude extends StatefulWidget {
  final int? radioGroupValue;

  Gratitude({this.radioGroupValue});

  @override
  _GratitudeState createState() => _GratitudeState();
}

class _GratitudeState extends State<Gratitude> {
  List<String> _list = ["AR Labs", "Library", "Cafeteria"];
  int? _groupValue; // Changed to int?
  String? _selected; // Changed to String?

  @override
  void initState() {
    super.initState();
    _groupValue = widget.radioGroupValue;
  }

  void _onChanged(int? index) { // Changed to int?
    setState(() {
      if (index != null) { // Null check
        _groupValue = index;
        _selected = _list[index];
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Select Location"),
        actions: [
          IconButton(
            icon: Icon(Icons.check),
            onPressed: () => Navigator.pop(context, _selected),
          )
        ],
      ),
      body: Column(
        children: List.generate(_list.length, (index) {
          return Row(
            children: [
              Radio(
                value: index,
                groupValue: _groupValue,
                onChanged: _onChanged, // Pass function directly
              ),
              Text(_list[index])
            ],
          );
        }),
      ),
    );
  }
}