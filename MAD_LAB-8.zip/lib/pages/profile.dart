// pages/profile.dart
import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Icon(Icons.person, size: 100, color: Colors.purple),
    );
  }
}
