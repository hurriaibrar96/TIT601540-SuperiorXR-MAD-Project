// pages/ar_screen.dart
import 'package:flutter/material.dart';
import 'ar_detail.dart';

class ARScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: GestureDetector(
        child: Hero(
          tag: "ar_icon",
          child: Icon(Icons.view_in_ar, size: 100, color: Colors.purple),
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ARDetail()),
          );
        },
      ),
    );
  }
}
