package com.example.mad_lab8

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
